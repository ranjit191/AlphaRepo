package com.textmaxx.Interfaces;

/**
 * Created by sumit on 25/1/17.
 */
public interface OnNotificationReceived {


    public void Notificationreceived();

}
