package com.textmaxx.retro;

/**
 * Created by manbir on 10/20/2016.
 */

public class ModelChangePas {

    private String password;

    public ModelChangePas(String password) {
        this.password = password;
    }



}
