package com.textmaxx.Interfaces;

/**
 * Created by root on 8/8/17.
 */

public interface onRecyclerClick {

    public void onRecyclerItemClick(int pos);
}
