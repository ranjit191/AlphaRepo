package com.textmaxx.retro;

/**
 * Created by manbir on 10/20/2016.
 */

public class RegisterTask {

    private String first_name;
    private String last_name;
    private String email_address;
    private String login;
            public RegisterTask(String first_name, String last_name, String email_address,String login) {
        this.first_name = first_name;
        this.last_name = last_name;
        this.email_address = email_address;
        this.login = login;
    }



}
