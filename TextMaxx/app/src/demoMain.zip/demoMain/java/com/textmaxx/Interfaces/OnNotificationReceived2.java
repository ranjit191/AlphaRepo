//package com.textmaxx.Interfaces;
//
///**
// * Created by sumit on 25/1/17.
// */
//public interface OnNotificationReceived2 {
//
//
//    public void Notificationreceived2();
//}
