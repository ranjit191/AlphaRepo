package com.textmaxx.retro;

/**
 * Created by manbir on 10/20/2016.
 */

public class DeleteAwait {

    private String awaiting;
    public DeleteAwait(String awaiting) {
        this.awaiting = awaiting;
    }



}
