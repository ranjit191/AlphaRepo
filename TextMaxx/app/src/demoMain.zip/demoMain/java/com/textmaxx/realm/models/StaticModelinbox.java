//package com.textmaxx.realm.models;
//
//import io.realm.RealmObject;
//import io.realm.annotations.Required;
//
//public class StaticModelinbox extends RealmObject {
//
//    @Required
//    private String title;
//    private String message;
//
//    public String getTemp_id() {
//        return title;
//    }
//
//    public void setTemp_id(final String title) {
//        this.title = title;
//    }
//
//
//    public String getLabel() {
//        return message;
//    }
//
//    public void setLabel(final String message) {
//        this.message = message;
//    }
//
//
//}