//package com.textmaxx.realm.models;
//
//import io.realm.RealmObject;
//import io.realm.annotations.PrimaryKey;
//import io.realm.annotations.Required;
//
//public class StaticModelContacts extends RealmObject {
//
//    private String title;
//
//    public StaticModelContacts(String title) {
//        this.title = title;
//    }
//
//    public StaticModelContacts() {
//
//    }
//
//    public String getTitle() {
//        return title;
//    }
//
//    public void setTitle(String title) {
//        this.title = title;
//    }
//}