package com.textmaxx.Interfaces;

import android.widget.ImageView;
import android.widget.RelativeLayout;

/**
 * Created by sumit on 18/10/16.
 */
public interface ImageClickListenerInterfaceRel {
    public void ImageClickRel(RelativeLayout imageView);
}
