package com.textmaxx.Utils;

/**
 * Created by sumit on 7/12/16.
 */
public class GlobalConstants {

    public static final String PREF_NAME = "pref_name";
    public static final String TOKEN = "token";
    public static final String ERROR = "error";
    public static final String RESET = "reset";
    public static final String URL = "url";
    public static final String APP_URL = "http://textmaxxpro.com";
    public static final String APP_FB = "https://www.facebook.com/textmaxxpro/";
    public static final String APP_YOUTUBE = "https://www.youtube.com/channel/UCJVyXztIap_igWjLa8B5-sw";
    public static final int NOTIFICATION_ID = 100;
    public static final int NOTIFICATION_ID_BIG_IMAGE = 101;
    public static final String PUSH_NOTIFICATION = "pushNotification";
    public static String ID = "id";
    public static String YOUTUBE_KEY = "AIzaSyDYrOevuonrREFWYTWJGLl9qW78p-nqc0M";
            public static String BASE_URL = "https://api.paymaxxpro.com/sms";
//    public static String BASE_URL = "https://sandbox.paymaxxpro.com/sms";
public static String VERSION_URL = "http://dev614.trigma.us/textMax_client_Imran/webservice.php?sectet_key=3689";

}











