package com.textmaxx.Interfaces;

import android.widget.ImageView;
import android.widget.RelativeLayout;

/**
 * Created by sumit on 18/10/16.
 */
public interface ImageClickListenerInterface {
    public void ImageClick(ImageView imageView);


//    public void ImageClick(RelativeLayout imageView);
}
