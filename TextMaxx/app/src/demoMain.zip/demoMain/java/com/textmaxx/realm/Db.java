package com.textmaxx.realm;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.textmaxx.R;

public class Db extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_db);
        
    }

}
