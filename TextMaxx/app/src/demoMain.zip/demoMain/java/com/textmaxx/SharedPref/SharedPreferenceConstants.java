package com.textmaxx.SharedPref;

/**
 * Created by tuffgeekers on 7-07-2016.
 */


public class SharedPreferenceConstants {
    public static String username = "demo@gmail.com";
    public static String password = "demo";
    public static String infoPage = "infoPage";
    public static String DEVICE_TOKEN = "token";
    public static String CLIENT_USER_TOKEN = "client_user";
    public static String IS_LOGGED_IN = "isloggedin";
    public static String find_user_identity = "finduser";
    public static String ID = "id";
    public static String CLIENT_TOKEN = "client";
    public static String CHATCODE = "chat_code";
    public static String DEVICETOKEN = "device_token";
    public static String MOBILITYID = "MOBILE_ID";
    public static String CHAT_SCREEN_CELL = "chat_cellno";
    public static String GO_BACK_LOC = "go_back_loc";
    public static String VARIFIED_FOR_CHAT = "varified";

    public static String TOKEN_NULL_CHECK = "tokenNull";
    public static String ARRAY_NAME_INBOX = "array_name_inbox";
    public static String ARRAY_NAME_CONTACTS = "array_name_contacts";
    public static String ACTIVITY = "activity";
    public static String PUSH = "pushcame";
//    public static String PUSH_COUNT = "0";
    public static String FCM_COUNT = "fcm_count";
    public static String VERSION_CODE = "fcm_count";
}